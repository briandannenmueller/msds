#!/usr/bin/python3
#-*- coding: utf-8 -*-

'''
@Version: vanilla
@Author: Meiying Chen
@Date: 2019-12-01 19:42:38
@LastEditTime: 2019-12-06 21:51:07
'''
# With much love~


import matplotlib.pyplot as plt
import random
import math
import numpy as np
import sys

def load_data(filename):
    # Assume data is in CSV format, float-valued features
    # binary category (zero or one) on right.
    data = np.array([[float(x) for x in line.strip().split(',')]
                     for line in open(filename).readlines()])
    return data

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

def infer(obs, params):
    """ Calculate sigmoid(w.x) """ 
    acc = params[len(obs)] # bias param in last position
    for n in range(len(obs)-1):
        acc += params[n]*obs[n]
    return sigmoid(acc)
    
def classify(obs, params):
    raw = infer(obs, params)
    return int(raw > 0.5)


def accuracy(data, params):

    correct = 0
    for obs in data:
        if (classify(obs[:-1], params) == obs[-1]):
            correct += 1
    return correct / len(data)

def loss_ss(data, params):
    acc = 0
    for obs in data:
        acc += (infer(obs[:-1],params) - obs[-1])**2
    return acc/len(data)
    
def learn(train, test, steps=500):
    delta = 1e-3
    gamma = 1
    batch_size = len(train)
    loss = loss_ss
    #loss = accuracy

    N = len(train[0])-1  # Dimension of input (i.e., number of features per example.)
    params = 0.5-np.random.rand(N+1)  # (uniform) random init params in range +- 0.5 centered at zero. 
    np.set_printoptions(linewidth=100, precision=3)
    steps_per_epoch = int(len(train)/batch_size)
    bestTest = accuracy(test, params)
    bestTrain = accuracy(train, params)

    acc_train = []
    acc_dev = []

    for epoch in range(steps):
        if epoch%50 == 0:
            print('epoch:', epoch)
        for i in range(steps_per_epoch):
            sample = random.sample(list(train),batch_size)  # without replacement
            cached = loss(sample, params)
            grad = np.zeros(N+1)
            for n in range(N+1):
                params[n] += delta
                grad[n] = (loss(sample, params)-cached)/delta
                params[n] -= delta
            #print("grad = " + str(grad))
            #params -= gamma**(epoch//10) * grad
            params -= gamma * grad

        acc_train_epoch = accuracy(train,params)
        acc_dev_epoch = accuracy(test,params)
        # bestTrain = max(bestTrain, acc_train_epoch)
        # bestTest = max(bestTest, acc_dev_epoch) 
        
        acc_train = acc_train + [acc_train_epoch]
        acc_dev = acc_dev + [acc_dev_epoch]
        # print('trainAcc=%.5f\ttestAcc=%.5f'%(acc_train_epoch, acc_dev_epoch))
    # print('bestTrain:', bestTrain)
    # print('bestTest', bestTest)
    
    # plot
    # plt.title('Accuracy vs Epochs (Logistic Regression)')
    # plt.xlabel('Epochs')
    # plt.ylabel('Accuracy')
    # plt.plot(acc_train, c='orange', label='Train')
    # plt.plot(acc_dev,c='green', label='Dev')
    # plt.legend()
    # plt.show()

    return np.array(acc_train), np.array(acc_dev)
    # return params

def demo():
    import pdb
    train = load_data(sys.argv[1])
    dev = load_data(sys.argv[2])
    params = learn(train, dev, 1000)
    # (uniform) random init params in range +- 0.5 centered at zero. 
    #params = 0.5-np.random.rand(len(data[0]))  
    print('trainAcc=%.5f\ttestAcc=%.5f'%(accuracy(train,params), accuracy(dev,params)))

def mydemo(train_file_path, dev_file_path):
    train = load_data(train_file_path)
    dev = load_data(dev_file_path)
    params = learn(train, dev)
    print('trainAcc=%.5f\ttestAcc=%.5f'%(accuracy(train,params), accuracy(dev,params)))


if __name__ == '__main__':
    pass
    # original
    # # mydemo('./data/sonar.train', './data/sonar.dev')

    # 30 times experiment
    # times = 3
    # res = {}
    # for t in range(times):
    #     print('train time:', t+1)
    #     train = load_data('./data/sonar.train')
    #     dev = load_data('./data/sonar.dev')
    #     acc_train, acc_dev = learn(train, dev,steps=5)
    #     if t == 0:
    #         res['train'] = acc_train
    #         res['dev'] = acc_dev
    #     res['train'] = res['train'] + acc_train
    #     res['dev'] = res['dev'] + acc_dev
    # ave_train = res['train']/float(times)
    # ave_dev = res['dev']/float(times) 

    # # plot
    # plt.title('Mean Accuracy vs Epochs (Logistic Regression)')
    # plt.xlabel('Epochs')
    # plt.ylabel('Mean Accuracy')
    # plt.plot(ave_train, c='orange', label='Train')
    # plt.plot(ave_dev,c='green', label='Dev')
    # plt.legend()
    # plt.savefig('./mean_acc_epoc_lr.png')
    # # plt.show()
    
    # box plot
    data = load_data('./data/sonar.test')
    import pandas as pd
    df = pd.DataFrame(data)
    df.boxplot()
    plt.title('Data Range of the Test Set')
    plt.xlabel('Feature #')
    plt.ylabel('Value')
    plt.show()  
    
