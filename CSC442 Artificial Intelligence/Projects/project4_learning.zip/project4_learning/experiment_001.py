from time import time
import activations
import numpy as np
import mlp
import loss

def load_sonar(path):
    with open(path) as fh:
        data = []
        for line in fh:
            elt = line.strip().split(',')
            xvals = [float(x) for x in elt[:-1]]
            yval = int(elt[-1])

            if yval == 0:
                data.append((xvals, [1, 0]))
            elif yval == 1:
                data.append((xvals, [0, 1]))
            else:
                print('unexpected yval=',yval)
    return data

def expt_001():
    train = load_sonar('data/sonar.train')
    dev = load_sonar('data/sonar.dev')
    test = load_sonar('data/sonar.test')


    gamma = 1     # the learning rate
    epochs = 100  # the maximum number of epochs
    


    layers = [12]  # one hidden layer with one hidden unit
    din = len(train[0][0])
    dout = len(train[0][1])

    m = mlp.MLP(layers, din, dout)


    lossfn = loss.sum_squares


    savefreq = 0   # store the model every savefreq steps
    logfreq = 1    # print updates every logfreq steps
    step = 0
    tsum = 0
    tbegin = time()
    for epoch in range(epochs):
        if ((epoch % logfreq) == 0):
            tloss = time()
            lss_train = m.loss(train, loss.zeroone)
            lss_dev = m.loss(dev, loss.zeroone)                
            tloss = time() - tloss
            print('Accuracy after %d rounds is %f train, %f dev '%(epoch, 1-lss_train, 1-lss_dev))
        m.gd_step(train, lossfn, gamma=gamma)


if __name__ == '__main__':
          expt_001()
