



Q: Do you notice an asymptote for the training data? If so, what is its value and how

many should you train to have a high probability of getting a good model?

A: Yes, the training set accuracy is  increasing and finally reached 1.0 after about 4000 epochs. So, if just considering the training set performance, 4000 epochs is a good choice.



Q: Do you notice an asymptote for the development data? If so, what is its value and how many should you train to have a high probability of getting a good model?

A: Yes, the dev set accuracy is slowly approaching 0.8. It takes about 650 epochs to reach the point that the dev set accuracy stops improving. After 650 epochs, the training set accuracy is still increasing but the dev set accuracy is decreasing, which means overfitting. So even if the training set accuracy have not yet stop going up, 650 epochs is good enough for getting a good model.





