####Report



####Project 4

####CSC 442 Artificial Intelligence

####Meiying Chen

####Dec. 9, 2019



####Part 1: Logistic Regression

**1. logistic regression setup**

Learning rate: 1.0

Total number of epochs: 1000

Final development set accuracy:  0.757575757575756 

Final training set accuracy:0.8741258741258742

Best development set accuracy: 0.7575757575757575 

Best training set accuracy: 0.8741258741258742

**2. logistic regression learning curve — single sample**

![acc_epoc_lr](/Users/dotdot/Desktop/project4_learning/img/acc_epoc_lr.png)

**3. logistic regression learning curve — mean of 30 trials**

![mean_acc_epoc_lr](/Users/dotdot/Desktop/project4_learning/img/mean_acc_epoc_lr.png)

**4. asymptote for logistic regression and estimated epochs for good performance**

Asymptote: the training set accuracy is slowly approaching 0.90.  The dev set accuracy is approaching 0.78.

Epochs: according to the mean-acc figure, it takes about 800 epochs to reach the point that the dev  set accuracy stops improving. So, for the dev set, 800 times of training  is necessary to have a good change of getting a working model. It is also the case for training set.

**5. did you observe any overfitting for logistic regression? explain your answer**

After 200 times of training, the gap between train set accuracy and dev set acc is roughly constant, which means when the dev set accuracy stops improving, the model do not continue fitting the train set too much. So there is not obvious overfitting.

**6. did you observe any underfitting  for logistic regression? explain your answer**

Before about 200 epochs, the model underfits as both train and dev accuracy are low. After 200 times of training,  both the train and dev set accuracy is  above 0.7, which is a good probability of classification problem. So there is no obvious underfitting.

**7. bonus for box-and-whiskers plot of logistic learning curve**

I choose five numbers of epochs around the best estimating epochs to draw the box plot blow. We can see the randomness is influencing the model. The training set data is stable. But we can see from the dev set data, the accuracy is  stable with a  very different outliner.

![box_train_lr](/Users/dotdot/Desktop/project4_learning/img/box_train_lr.png)

![box_dev_lr](/Users/dotdot/Desktop/project4_learning/img/box_dev_lr.png)

####Part 2: MLP

**1. neural network setup**

Learning rate: 0.25

Total number of epochs: 800

Final development set accuracy:  0.787879

Final training set accuracy: 0.881119

Best development set accuracy:  0.818182

Best training set accuracy: 0.881119

**2. neural network learning curve — single sample**

![acc_epoc_mlp](/Users/dotdot/Desktop/project4_learning/img/acc_epoc_mlp.png)

**3. neural network learning curve — mean of 30 trials**

![mean_acc_epoc_mlp](/Users/dotdot/Desktop/project4_learning/img/mean_acc_epoc_mlp.png)

**4. asymptote for neural network and epochs for good performance**

Asymptote:  the training set accuracy is  increasing and in my following test reached 1.0 after about 4000 epochs.  The dev set accuracy is  approaching a highest point at 0.78 before about 520 epochs, and slightly dropped after that.

Epochs for good performance: It is not suitable to choose the best epoch set according to the train set acc, because it keeps going until reaches 1.0. So for the dev set, as described above, the best choice is 520 epochs.

**5. did you observe any overfitting for logistic regression? explain your answer**

Yes. After about 520 epochs, the training set accuracy is going up until hits 1.0, but the dev set accuracy is going down. So after 520 epochs the model overfitted on the training set.

**6.  did you observe any underfitting for logistic regression? explain your answer**

Before about 200 epochs, the model underfits as both train and dev accuracy are low. After 200 times of training,  both the train and dev set accuracy is  above 0.65, which is a good. So there is no obvious underfitting.

**7. bonus for box-and-whiskers plot of neural network learning curve**

I choose five numbers of epochs around the best estimating epochs to draw the box plot blow. We can see the randomness  influence is not so  obvious. 

![box_train_mlp](/Users/dotdot/Desktop/project4_learning/img/box_train_mlp.png)

![box_train_mlp](/Users/dotdot/Desktop/project4_learning/img/box_train_mlp.png)

####Part 3: Put it all together

**1. best overall dev set accuracy observed; describes the setup**

Best overall dev set accuracy:  0.818182

Setup:

Method: MLP

Learning rate: 0.25

Number of epochs = 520

Larger learning rate does not converge, accuracy oscillation occurred.



Experiment times: 30

Mean accuracy on test set: 0.6527070707070709

Min accuracy on test set: 0.6110955710955749

Max accuracy on test set: 0.7248484848484898

Standard deviation of 30 times: 0.027233766093759458

**2. bonus for histogram of test accuracy using your chosen model**

![histogram](/Users/dotdot/Desktop/project4_learning/img/histogram.png)

